# minecraftonline.com World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 8 Dec 2025 16:22:57 +0800` (Timestamp: `1765182177713`)
- **Captured By**: `RetroLilly`

## Server
- **IP**: `minecraftonline.com`
- **Capacity**: `3/120`
- **Brand**: `SpongeVanilla`
- **MOTD**: `Welcome to dumponia!`
- **Version**: `1.12.2`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`
- **Short Label**: `JohnWickithy, Pyromaniest, Big_Ol_Sherb`
- **Full Label**: `JohnWickithy Pyromaniest Big_Ol_Sherb`

## Connection
- **Host Name**: `minecraftonline.com`
- **Port**: `25565`
- **Session ID**: `0ed865fc-ce41-4f74-b626-54db74e76c8f`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
